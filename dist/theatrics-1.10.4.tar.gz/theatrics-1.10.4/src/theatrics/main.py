import multiprocessing as mp
import tkinter as tk
from theatrics.launcher import TheatricsLauncher
from theatrics.utils.mp_utils import set_single_threaded_blas, setup_multiprocessing


def main():
    mp.freeze_support()  # MUST be first thing for Windows
    set_single_threaded_blas()
    setup_multiprocessing("spawn", force=True)

    root = tk.Tk()
    launcher = TheatricsLauncher(root)

    root.protocol("WM_DELETE_WINDOW", launcher.on_launcher_close)
    root.mainloop()


if __name__ == "__main__":
    main()